<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <title><?php echo $__env->yieldContent('title', 'SuaraGO'); ?></title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.7.0/fonts/remixicon.css" rel="stylesheet"/>

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/js/landing.js']); ?>

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        html {
            scroll-behavior: smooth;
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="bg-gray-50">

    
    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('partials.auth-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            
            // --- Fungsi Toast Notification ---
            window.showToast = function(message, type = 'success') {
                const toastId = 'dynamic-toast-message';
                let toastMessage = document.getElementById(toastId);
                if (toastMessage) toastMessage.remove(); 
                
                const bgColor = type === 'success' ? 'bg-green-500' : 'bg-red-500';
                toastMessage = document.createElement('div');
                toastMessage.id = toastId;
                toastMessage.className = `fixed top-24 right-5 z-[100] text-white py-3 px-5 rounded-lg shadow-lg ${bgColor} transition-opacity duration-500`;
                toastMessage.textContent = message;
                
                document.body.appendChild(toastMessage);
                
                // Hapus otomatis setelah 3 detik
                setTimeout(() => {
                    toastMessage.style.opacity = '0';
                    setTimeout(() => toastMessage.remove(), 500);
                }, 3000);
            };

            // --- Cek Flash Message dari Session (PHP) ---
            <?php if(session('success')): ?>
                showToast("<?php echo e(session('success')); ?>", 'success');
            <?php endif; ?>

            <?php if(session('error')): ?>
                showToast("<?php echo e(session('error')); ?>", 'error');
            <?php endif; ?>


        });
    </script>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\laragon\www\sistem-pengaduan-aspirasi\resources\views/layouts/app.blade.php ENDPATH**/ ?>