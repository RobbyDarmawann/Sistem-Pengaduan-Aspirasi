    <footer class="py-10 bg-gray-800 text-center">
        <div class="container mx-auto px-5">
            <p class="text-gray-300">&copy; 2025 Kelompok 5. Hak Cipta Dilindungi.</p>
        </div>
    </footer><?php /**PATH C:\laragon\www\sistem-pengaduan-aspirasi\resources\views/partials/footer.blade.php ENDPATH**/ ?>