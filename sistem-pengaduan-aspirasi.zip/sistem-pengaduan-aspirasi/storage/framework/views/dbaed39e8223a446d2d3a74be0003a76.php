

<?php $__env->startSection('title', 'Profil Saya - SuaraGO'); ?>

<?php $__env->startSection('content'); ?>

<div class="relative pt-16 pb-12 bg-[#5D9FD6]" 
     style="<?php echo e($user->cover_photo_path ? 'background-image: url('.asset('storage/'.$user->cover_photo_path).'); background-size: cover; background-position: center;' : ''); ?>">
    
    <?php if($user->cover_photo_path): ?> <div class="absolute inset-0 bg-[#5D9FD6]/80"></div> <?php endif; ?>

    <div class="container mx-auto px-5 md:px-20 relative z-10">
        <div class="flex flex-col md:flex-row items-center justify-between gap-6 text-white">
            
            <div class="flex flex-col md:flex-row items-center gap-6">
                <div class="relative">
                    <img src="<?php echo e($user->profile_photo_path ? asset('storage/' . $user->profile_photo_path) : asset('assets/images/profil-pengguna.jpg')); ?>" 
                         class="w-32 h-32 rounded-full object-cover border-4 border-white bg-white">
                </div>
                <div class="text-center md:text-left">
                    <h1 class="text-2xl font-bold"><?php echo e($user->full_name); ?></h1>
                    </div>
            </div>

            <div class="flex items-center gap-12">
                <div class="flex gap-10 text-center">
                    <?php if($user->show_pengaduan): ?>
                    <div>
                        <span class="block text-lg font-medium">Laporan</span>
                        <span class="block text-2xl font-bold"><?php echo e($laporanCount); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if($user->show_aspirasi): ?>
                    <div>
                        <span class="block text-lg font-medium">Aspirasi</span>
                        <span class="block text-2xl font-bold"><?php echo e($aspirasiCount); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                <div>
                    <a href="<?php echo e(route('profil.edit')); ?>" class="px-6 py-2 border border-white rounded-lg font-medium hover:bg-white/10 transition text-white">
                        Ubah Profil
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="container mx-auto px-5 md:px-20 py-10">
    
    <div class="text-center mb-8 relative">
        <h2 class="text-xl font-bold text-black inline-block border-b-2 border-black pb-1">Daftar Laporan dan Aspirasi Anda</h2>
    </div>

    <div class="flex flex-col md:flex-row border-2 border-[#5D9FD6] rounded-t-lg overflow-hidden">
        
        <div class="w-full md:w-1/4 bg-[#5D9FD6] text-white flex flex-col min-h-[500px]">
            <div class="py-4 text-center font-bold text-lg border-b border-white/30">
                Filter
            </div>
            <nav class="flex flex-col font-bold text-sm md:text-base">
                <a href="<?php echo e(route('profil.index', ['tab' => 'all', 'type' => $type])); ?>" 
                   class="px-6 py-4 hover:bg-white/20 border-b border-white/30 transition <?php echo e($tab == 'all' ? 'bg-white/20' : ''); ?>">
                    Semua Unggahan
                </a>
                <a href="<?php echo e(route('profil.index', ['tab' => 'pending', 'type' => $type])); ?>" 
                   class="px-6 py-4 hover:bg-white/20 border-b border-white/30 transition <?php echo e($tab == 'pending' ? 'bg-white/20' : ''); ?>">
                    Menunggu Persetujuan
                </a>
                <a href="<?php echo e(route('profil.index', ['tab' => 'process', 'type' => $type])); ?>" 
                   class="px-6 py-4 hover:bg-white/20 border-b border-white/30 transition <?php echo e($tab == 'process' ? 'bg-white/20' : ''); ?>">
                    Menunggu Tanggapan
                </a>
                <a href="<?php echo e(route('profil.index', ['tab' => 'finished', 'type' => $type])); ?>" 
                   class="px-6 py-4 hover:bg-white/20 border-b border-white/30 transition <?php echo e($tab == 'finished' ? 'bg-white/20' : ''); ?>">
                    Selesai Ditanggapi
                </a>
            </nav>
        </div>

        <div class="w-full md:w-3/4 bg-[#F8FAFC]">
            
           <div class="flex border-b border-gray-200 bg-[#5D9FD6]">
                
                <?php if($type == 'aspirasi'): ?>
                    <div class="w-1/2 text-center py-4 font-bold text-lg bg-[#F8FAFC] text-[#5D9FD6] border-t-4 border-t-[#5D9FD6] cursor-default">
                        Aspirasi
                    </div>
                <?php else: ?>
                    <a href="<?php echo e(route('profil.index', ['type' => 'aspirasi', 'tab' => $tab])); ?>" 
                       class="w-1/2 text-center py-4 font-medium text-lg text-white hover:bg-white/10 transition-colors border-b-4 border-b-transparent cursor-pointer">
                        Aspirasi
                    </a>
                <?php endif; ?>
                
                <?php if($type == 'pengaduan'): ?>
                    <div class="w-1/2 text-center py-4 font-bold text-lg bg-[#F8FAFC] text-[#5D9FD6] border-t-4 border-t-[#5D9FD6] cursor-default">
                        Pengaduan
                    </div>
                <?php else: ?>
                    <a href="<?php echo e(route('profil.index', ['type' => 'pengaduan', 'tab' => $tab])); ?>" 
                       class="w-1/2 text-center py-4 font-medium text-lg text-white hover:bg-white/10 transition-colors border-b-4 border-b-transparent cursor-pointer">
                        Pengaduan
                    </a>
                <?php endif; ?>

            </div>

            <div class="p-6 space-y-4 flex-1">
                <?php $__empty_1 = true; $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="bg-white rounded-xl border-2 border-[#5D9FD6] p-4 flex flex-col md:flex-row gap-4 items-center relative shadow-sm">
                        
                        <div class="flex flex-col items-center w-24 flex-shrink-0">
                            <img src="<?php echo e($item->visibilitas == 'anonim' ? asset('assets/images/logo-icon.png') : ($user->profile_photo_path ? asset('storage/'.$user->profile_photo_path) : asset('assets/images/profil-pengguna.jpg'))); ?>" 
                                 class="w-16 h-16 rounded-full object-cover border border-gray-300 mb-2">
                            <span class="text-sm font-bold text-gray-700 text-center break-words w-full">
                                <?php echo e($item->visibilitas == 'anonim' ? 'Anonim' : explode(' ', $user->full_name)[0]); ?>

                            </span>
                        </div>

                        <div class="flex-1 border-l border-gray-200 pl-4 py-1">
                            <div class="flex justify-between text-xs text-gray-500 mb-1">
                                <div class="flex items-center gap-2">
                                    <i class="ri-calendar-line"></i> <?php echo e($item->created_at->format('d F, H:i')); ?>

                                </div>
                                <div class="font-mono">Tracking ID: #<?php echo e($item->id . Str::random(3)); ?></div>
                            </div>

                            <h3 class="font-bold text-lg text-black mb-1 leading-snug"><?php echo e($item->judul); ?></h3>
                            <p class="text-sm text-gray-700 mb-2 line-clamp-2"><?php echo e($item->isi_laporan); ?></p>
                            
                            <div class="text-xs text-gray-600">
                                Terdisposisi ke <span class="font-bold"><?php echo e($item->instansi_tujuan); ?></span>
                            </div>
                        </div>

                        <div class="flex-shrink-0 w-32 flex justify-center">
                            <?php
                                $badgeClass = match($item->status) {
                                    'belum_disetujui' => 'bg-gray-200 text-gray-700',
                                    'diproses' => 'bg-[#FFC107] text-white border-2 border-[#FFC107]', // Kuning
                                    'selesai' => 'bg-green-500 text-white',
                                    default => 'bg-red-500 text-white'
                                };
                                $statusText = match($item->status) {
                                    'belum_disetujui' => 'Menunggu',
                                    'diproses' => 'Sedang Diproses',
                                    'selesai' => 'Selesai',
                                    default => 'Ditolak'
                                };
                            ?>
                            <span class="<?php echo e($badgeClass); ?> font-bold px-2 py-3 rounded-lg text-xs text-center w-full block shadow-sm leading-tight">
                                <?php echo str_replace(' ', '<br>', $statusText); ?>

                            </span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="flex flex-col items-center justify-center h-64 text-gray-400">
                        <p>Belum ada data <?php echo e($type); ?> di sini.</p>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sistem-pengaduan-aspirasi\resources\views/profil/index.blade.php ENDPATH**/ ?>