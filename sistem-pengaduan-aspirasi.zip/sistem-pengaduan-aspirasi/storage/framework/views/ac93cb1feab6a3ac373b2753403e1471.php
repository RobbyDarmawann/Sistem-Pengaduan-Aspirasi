    <?php if(session('success')): ?>
        <div id="alert-message" class="fixed top-24 right-5 z-[100] bg-green-500 text-white py-3 px-5 rounded-lg shadow-lg">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php /**PATH C:\laragon\www\sistem-pengaduan-aspirasi\resources\views/partials/alert.blade.php ENDPATH**/ ?>